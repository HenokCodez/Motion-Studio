import React from 'react';
// Per-video custom animations (ids C01, C02, ...). Add: import meta from '../animations/meta/C01.json'; import {C01} from './C01';
// then push {meta, Component: withFonts(C01)} below (withFonts from '../primitives'). See references/creative-brief.md.
export const customRegistry: {meta: any; Component: React.FC<any>}[] = [];
